<?php
   $title = "Advance Auto Parts"; 
   include ('header.php') ;
  ?>
<script type="text/javascript" src="js/count.js"></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<link rel="stylesheet" type="text/css" href="css/exhibitor.css">
<script type="text/javascript" src="js/menu.js"></script>
<link href='https://fonts.googleapis.com/css?family=Gafata|Roboto:700' rel='stylesheet' type='text/css'>

<header class="videohead">

	<!-- Video from coverr.co -->
    <video class="video-bg" autoplay muted loop>

		<source src="img/preview.webm" type="video/webm">
        <source src="img/preview.mp4" type="video/mp4">
        <source src="img/preview.ogv" type="video/ogg">
	</video>
	<div class="video-overlay">
		<h1 class="shadow container">Advance Auto Parts </h1>
        
        <a href="booking.php" class="btn btn-primary mianbutton container" style="text-align: center;">Book Mechanics</a>
	</div>

</header>










<?php

   include ('footer.php') ;
  ?>


