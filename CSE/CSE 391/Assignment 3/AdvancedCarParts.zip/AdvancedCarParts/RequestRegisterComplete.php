<?php


   $title = "Request Complete"; 
   include ('header.php') ;


  ?>
 
<div class="container" >
  <div class="col-lg-8" style="margin: 40px;">
    <table class="table table-bordered">
       <tr class="warning">
          <td><h2>Thank you for choosing us</h2></td>
        </tr>

        <tr class="warning">
          <td>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
              <p>Dear Customer</p>
              <p>We have recieved your Request. We will contact you soon.<br> If you think you have made any mistake please mail at sakibapon7@gmail.com or open <a href="javascript:void(Tawk_API.toggle())">the chat box</a> and message us.</p>
            </div>
          </td>
        </tr>

    </table>
  </div>

</div>

<?php include ('footer.php') ?>

