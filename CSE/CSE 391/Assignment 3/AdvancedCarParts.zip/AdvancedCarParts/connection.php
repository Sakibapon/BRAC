<?php
	$db = mysqli_connect("localhost", "root", "", "assignment");

?>