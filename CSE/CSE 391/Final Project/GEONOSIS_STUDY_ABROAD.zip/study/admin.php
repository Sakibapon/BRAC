<style type="text/css">
	.successcentering{
		text-align: center;
	}
</style>
<?php
error_reporting(0);
include('all_products.php');
$title = "Admin Panel"; 
include ('header.php') ;
	// if upload button is pressed
	if (isset($_POST['add_item'])) {
		// the path to store the image
		$targetA = "university/".basename($_FILES['a_img']['name']);
		$targetB = "university/".basename($_FILES['b_img']['name']);
		$targetC = "university/".basename($_FILES['c_img']['name']);
		$targetD = "university/".basename($_FILES['d_img']['name']);
		$targetE = "university/".basename($_FILES['e_img']['name']);
		$targetF = "university/".basename($_FILES['f_img']['name']);

		// connect to database

		include ('connection.php');

		// get all the submitted data from the form

		$aimage = $_FILES['a_img']['name'];
		$bimage = $_FILES['b_img']['name'];
		$cimage = $_FILES['c_img']['name'];
		$dimage = $_FILES['d_img']['name'];
		$eimage = $_FILES['e_img']['name'];
		$fimage = $_FILES['f_img']['name'];

		$university = $_POST['university'];
		$uniweb = $_POST['uniweb'];
		$interstudent = $_POST['interstudent'];
		$year = $_POST['year'];
		$type = $_POST['type'];
		$campsize = $_POST['campsize'];
      	$campussize = $_POST["campussize"];
      	$malefemaleratio = $_POST["malefemaleratio"];		
		$endvalue = $_POST['endvalue'];
		$foreignstudent = $_POST['foreignstudent'];
		$rank = $_POST['rank'];
		$applicationfee = $_POST['applicationfee'];
		$minimumGrade = $_POST['minimumGrade'];
		$address = $_POST['address'];
		$phone = $_POST['phone'];
		$uniemail = $_POST["uniemail"];
		$city = $_POST["city"];
		$hostelmeal = $_POST['hostelmeal'];
		$avgtution = $_POST['avgtution'];
		$description = $_POST['description'];
		
		

		$sql = "INSERT INTO uni (university, uniweb, interstudent, year, type, campsize, campussize, malefemaleratio, endvalue, foreignstudent, rank, applicationfee, minimumGrade, address, phone,uniemail,city, hostelmeal, avgtution,description, image1, image2, image3, image4, image5, image6) 
			VALUES ('$university','$uniweb' , '$interstudent','$year','$type','$campsize','$campussize' ,'$malefemaleratio' ,'$endvalue','$foreignstudent', '$rank','$applicationfee','$minimumGrade','$address','$phone','$uniemail','$city','$hostelmeal','$avgtution','$description','$aimage', '$bimage', '$cimage', '$dimage', '$eimage', '$fimage')";

		$addQuery = mysqli_query($db, $sql); // store the submitted data to the database..

		if ($addQuery) {
			echo '<div class="alert alert-success successcentering">';
  			echo "<strong>Success!</strong> Item added.";
			echo "</div>";
		}
		else{
			echo '<div class="alert alert-danger successcentering">';
  			echo "<strong>Failed!</strong> Item not added. Try again";
			echo "</div>";
		}

		//now move the uploaded image to the htdocs directory

		if (move_uploaded_file($_FILES['a_img']['tmp_name'], $targetA)) {
			$msg = "Image uploaded successfully";
		}else{
			$msg = "There is an error uploading the image";
		}

		if (move_uploaded_file($_FILES['b_img']['tmp_name'], $targetB)) {
			$msg = "Image uploaded successfully";
		}else{
			$msg = "There is an error uploading the image";
		}

		if (move_uploaded_file($_FILES['c_img']['tmp_name'], $targetC)) {
			$msg = "Image uploaded successfully";
		}else{
			$msg = "There is an error uploading the image";
		}

		if (move_uploaded_file($_FILES['d_img']['tmp_name'], $targetD)) {
			$msg = "Image uploaded successfully";
		}else{
			$msg = "There is an error uploading the image";
		}

		if (move_uploaded_file($_FILES['e_img']['tmp_name'], $targetE)) {
			$msg = "Image uploaded successfully";
		}else{
			$msg = "There is an error uploading the image";
		}

		if (move_uploaded_file($_FILES['f_img']['tmp_name'], $targetF)) {
			$msg = "Image uploaded successfully";
		}else{
			$msg = "There is an error uploading the image";
		}


	}

	// if modify button is pressed
	if (isset($_POST['modify_item'])) {
		// connect to database
		include ('connection.php');

		$id = $_POST['id'];
		$university = $_POST['m_university'];
		$uniweb = $_POST['m_uniweb'];
		$interstudent = $_POST['m_interstudent'];
		$year = $_POST['m_year'];
		$type = $_POST['m_type'];
		$campsize = $_POST['m_campsize'];
      	$campussize = $_POST["m_campussize"];
      	$malefemaleratio = $_POST["m_malefemaleratio"];
		$endvalue = $_POST['m_endvalue'];
		$foreignstudent = $_POST['m_foreignstudent'];
		$rank=$_POST['m_rank'];
		$applicationfee = $_POST['m_applicationfee'];
		$minimumGrade = $_POST['m_minimumGrade'];
		$address = $_POST['m_address'];
		$phone = $_POST['m_phone'];
		$uniemail = $_POST['m_uniemail'];
		$city = $_POST['m_city'];
		$hostelmeal = $_POST['m_hostelmeal'];
		$avgtution = $_POST['m_avgtution'];
		$description = $_POST['m_description'];
		
		
		$sql = "UPDATE uni SET university = '$university', uniweb = '$uniweb' , interstudent = '$interstudent', year = '$year', type = '$type', campsize = '$campsize',campussize='$campussize', malefemaleratio='$malefemaleratio', endvalue = '$endvalue', foreignstudent = '$foreignstudent',rank='$rank' ,applicationfee = '$applicationfee', minimumGrade = '$minimumGrade', address = '$address', uniemail = '$uniemail' ,phone = '$phone',city = '$city', hostelmeal = '$hostelmeal', avgtution = '$avgtution', description = '$description' WHERE id = '$id'";

		$modifyQuery = mysqli_query($db, $sql); // store the submitted data to the database..
		if ($modifyQuery && $id) {
			echo '<div class="alert alert-success successcentering">';
  			echo "<strong>          Success!</strong> Item modified.";
			echo "</div>";
		}
		else{
			echo '<div class="alert alert-danger successcentering">';
  			echo "<strong>          Failed!</strong> Item not modified.";
			echo "</div>";			
		}
	}

	// if modify availability button is pressed
	if (isset($_POST['modify_availability'])) {
		// connect to database
		include ('connection.php');

		$id = $_POST['a_id'];
		$availability = $_POST['m_availability'];
		
		$sql = "UPDATE uni SET availability = '$availability' WHERE id = '$id'";

		$modifyAQuery = mysqli_query($db, $sql); // store the submitted data to the database..
		if ($modifyAQuery && $id) {
			echo '<div class="alert alert-success">';
  			echo "<strong>          Success!</strong> Item availability changed.";
			echo "</div>";
		}
	}

	if (isset($_POST['delete_item'])) {
		// connect to database
		include ('connection.php');

		$id = $_POST['a_id'];
		
		$sql = "DELETE from uni WHERE id = '$id'";

		$deleteQuery = mysqli_query($db, $sql); // store the submitted data to the database..
		if ($deleteQuery && $id) {
			echo '<div class="alert alert-success successcentering">';
  			echo "<strong>Success!</strong> Item deleted.";
			echo "</div>";
		}
		
			
	}

	// if reupload image button is pressed
	if (isset($_POST['modify_images'])) {
		// the path to store the image
		$targetA = "university/".basename($_FILES['a_img']['name']);
		$targetB = "university/".basename($_FILES['b_img']['name']);
		$targetC = "university/".basename($_FILES['c_img']['name']);
		$targetD = "university/".basename($_FILES['d_img']['name']);
		$targetE = "university/".basename($_FILES['e_img']['name']);
		$targetF = "university/".basename($_FILES['f_img']['name']);

		// connect to database

		include ('connection.php');

		// get all the submitted data from the form

		$aimage = $_FILES['a_img']['name'];
		$bimage = $_FILES['b_img']['name'];
		$cimage = $_FILES['c_img']['name'];
		$dimage = $_FILES['d_img']['name'];
		$eimage = $_FILES['e_img']['name'];
		$fimage = $_FILES['f_img']['name'];

		$id = $_POST['id'];
		$sql = "UPDATE uni SET image1 = $aimage, image2 = $bimage, image3 = $cimage, image4 = $dimage, image5 = $eimage, image6 = $fimage WHERE id = '$id";

		mysqli_query($db, $sql); // store the submitted data to the database..

		//now move the uploaded image to the htdocs directory

		if (move_uploaded_file($_FILES['a_img']['tmp_name'], $targetA)) {
			$msg = "Image uploaded successfully";
		}else{
			$msg = "There is an error uploading the image";
		}

		if (move_uploaded_file($_FILES['b_img']['tmp_name'], $targetB)) {
			$msg = "Image uploaded successfully";
		}else{
			$msg = "There is an error uploading the image";
		}

		if (move_uploaded_file($_FILES['c_img']['tmp_name'], $targetC)) {
			$msg = "Image uploaded successfully";
		}else{
			$msg = "There is an error uploading the image";
		}

		if (move_uploaded_file($_FILES['d_img']['tmp_name'], $targetD)) {
			$msg = "Image uploaded successfully";
		}else{
			$msg = "There is an error uploading the image";
		}

		if (move_uploaded_file($_FILES['e_img']['tmp_name'], $targetE)) {
			$msg = "Image uploaded successfully";
		}else{
			$msg = "There is an error uploading the image";
		}

		if (move_uploaded_file($_FILES['f_img']['tmp_name'], $targetF)) {
			$msg = "Image uploaded successfully";
		}else{
			$msg = "There is an error uploading the image";
		}

	}


$pass = $_POST['pass'];

if ($_SESSION['username']=="admin")
{
        include("adminLayout.php");

}
else
{

/*    if(isset($_POST))
   {echo '
    	<div class="container"></div>
    	<div style="text-align: center; margin-top: 50px;" class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <form method="POST" action="admin.php">
            <h3><span class="glyphicon glyphicon-lock">Password</h3>
            <input type="password" name="pass"></input>
            <input type="submit" name="submit" value="Go"></input>
            </form>
        </div>';
    }
    */
    header('location: index.php');
}


?>
<?php include ('footer.php') ?>