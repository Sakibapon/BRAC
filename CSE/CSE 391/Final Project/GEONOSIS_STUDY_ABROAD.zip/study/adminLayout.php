<link rel="stylesheet" type="text/css" href="css/adminlayout.css">
<div >
	<div class="sidenav" >
	<div style="border: 1px solid white;">
	  <a href="#adduni">Add University</a>
	</div>
	<a href="#"></a>
	<div style="border: 1px solid white;">
	  <a href="#manage">Manage Consultation</a>
	</div>  
	<a href="#"></a>
	<div style="border: 1px solid white;">
	  <a href="#moduni">Modify University</a>
	</div>
	<a href="#"></a>
	<div style="border: 1px solid white;">
	  <a href="#removeuni">Remove University</a>
	 </div>
	</div>




<div id="adduni" class="main " style="border: 3px solid black; padding: 20px;background-image: url(img\ca.jpg);" >
	<h1 style="text-align: center;" class=" check" style="font-size:60px; ">Add An Univeristy</h1>
	<form method="post" action="admin.php" enctype="multipart/form-data" class="adminlay">
		<table class="table table-bordered">
			<tr class="adminlays">
				<td>
					<label>Category</label>
				</td>
				<td>
					<select name="type" class="form-control">
						<option value="usa">USA</option>
						<option value="ca">Canada</option>
						<option value="germany">Germany</option>
						<option value="aus">Australlia</option>
						<option value="uk">United Kingdom</option>
						<option value="spain">Spain</option>
						<option value="italy">Italy</option>
						<option value="france">France</option>
						<option value="malaysia">Malaysia</option>
					</select>
				</td>
			</tr>

			<tr class="adminlay">
				<td>
					<label>Univeristy</label>
				</td>
				<td>
					<input type="text" name="university" placeholder="Ex: MIT" class="form-control">
				</td>
				
			</tr>

			<tr class="adminlays">
				<td>
					<label>Univeristy Website</label>
				</td>
				<td>
					<input type="text" name="uniweb" placeholder="Ex: www.ubc.com"  class="form-control">
				</td>
				
			</tr>

			<tr class="adminlay">
				<td>
					<label>International Students Percentage</label>
				</td>
				<td>
					<input type="text" name="interstudent" placeholder="Enter Number Only" class="form-control">
				</td>
			</tr>

			<tr class="adminlays">
				<td>
					<label>Established In</label>
				</td>
				<td>
					<input type="text" name="year" placeholder="Ex: 2019"  class="form-control">
				</td>
			</tr>





			


			<tr class="adminlay">
				<td>
					<label>No.of Campuses</label>
				</td>
				<td >
					
					<input type="radio" name="campsize" value="1" id="1"><label for="1"> 1 </label>
					<input type="radio" name="campsize" value="2" id="2"><label for="2"> 2 </label>
					<input type="radio" name="campsize" value="3" id="3"><label for="3"> 3 </label>
					
				</td>
			</tr>

			<tr class="adminlays">
				<td>
					<label>Campus Size</label>
				</td>
				<td>
					<input type="text" name="campussize" placeholder="Ex: 120 Acres" class="form-control">
				</td>
			</tr>

			<tr class="adminlay">
				<td>
					<label>Male/Female Ratio</label>
				</td>
				<td>
					<input type="text" name="malefemaleratio" placeholder="Ex: 1 : 1.12" class="form-control">
				</td>
			</tr>

			<tr class="adminlays">
				<td>
					<label>Endowments Value</label>
				</td>
				<td>
					<input type="number" name="endvalue" placeholder="Ex: 394 " class="form-control">
				</td>
			</tr>

			<tr class="adminlay">
				<td>
					<label>Students Belonging To</label>
				</td>
				<td>
					<input type="text" name="foreignstudent" placeholder="Ex: 110 Countries|Enter Number Only" class="form-control">
				</td>
			</tr>

			<tr class="adminlays">
				<td>
					<label>Rank</label>
				</td>
				<td>
					<input type="number" name="rank" placeholder="Ex: 560"  class="form-control"></input>
					
				</td>
			</tr>

			<tr class="adminlay">
				<td>
					<label>Application Fees</label>
				</td>
				<td>
					<input type="number" name="applicationfee" placeholder="Ex: 126 " class="form-control">
				</td>
			</tr>



			<tr class="adminlays">

				<td>
					<label>Minimum Grade Percentage</label>
				</td>
				<td>
					<input type="number" name="minimumGrade" placeholder="Ex: 80%" class="form-control">
				</td>
			</tr>

			<tr class="adminlay">
				<td>
					<label>Address</label>
				</td>
				<td>
					<input type="text" name="address" placeholder="Ex: Victoria, BC V8P 5C2, Canada" class="form-control">
				</td>
			</tr>

			<tr class="adminlays">
				<td>
					<label>Phone</label>
				</td>
				<td>
					<input type="text" name="phone" placeholder="Ex: 250-472-5462" class="form-control">
				</td>
			</tr>

			<tr class="adminlay">
				<td>
					<label>University Email</label>
				</td>
				<td>
					<input type="text" name="uniemail" placeholder="Ex: something@gmail.com" class="form-control">
				</td>
			</tr>

			<tr class="adminlays">
				<td>
					<label>City</label>
				</td>
				<td>
					<input type="text" name="city" placeholder="Ex: Vancouver,CA" class="form-control">
				</td>
			</tr>

			<tr class="adminlay">
				<td>
					<label>Yearly Hostel & Meal Cost</label>
				</td>
				<td>
					<input type="number" name="hostelmeal" placeholder="Ex: 15000" class="form-control">
				</td>
			</tr>

			<tr class="adminlays">
				<td>
					<label>Average Tuition Fees</label>
				</td>
				<td>
					<input type="number" name="avgtution" placeholder="Ex: 12000" class="form-control">
				</td>
			</tr>

			<tr class="adminlay">
				<td>
					<label>Description</label>
				</td>
				<td>
					<textarea name="description" placeholder="Ex: Public University" class="form-control"></textarea>
				</td>
			</tr>


			<tr class="adminlays">
				<td>
					<label>Thumbnail Images</label>
				</td>
				<td >
					<input type="file" name="a_img" >
					<input type="file" name="b_img">
					<input type="file" name="c_img">
					<input type="file" name="d_img">
					<input type="file" name="e_img">
					<input type="file" name="f_img">
				</td>
			</tr>



			<tr class="adminlay">
				<td>
					<label>Is everything okay ?</label>
				</td>
				<td>
					<input type="hidden" name="pass" value="asdfghjkl"></input>
					<button type="submit" class="btn btn-success" name="add_item" value="submit">Add Univeristy</button>
				</td>
			</tr>

		</table>
	</form>

		
</div>


<div id="manage" class="main" style="padding: 20px; border: 3px solid black;" >
		
	<h1 style="text-align: center; " class=" check " style="font-size:60px; ">Consultation Management</h1>		
		<table class="table table-bordered">
			<tr class="warning">
				<td class="text-center">
					<a class="btn btn-primary " href="manageConsultation.php">Manage Consultations</a>
				</td>
			</tr>

		</table>
</div>


																		




<div id="moduni" class="main" style="padding: 20px; border: 3px solid black;">
	<h1 class="check" style="text-align: center;">Modify An Univeristy</h1>
	<form method="post"  enctype="multipart/form-data">
		<table class="table table-bordered">
			<tr class="adminlays">
				<td>
					<label >University ID</label>
				</td>
				<td >
					<input class="form-control" type="number" name="id">
					<input class="hidden" type="button" name="idBtn" value="Get Details" >
				</td>
			</tr>

			<tr class="adminlay">
				<td>
					<label>Category</label>
				</td>
				<td>
					<select name="m_type" class="form-control">
						<option value="usa">USA</option>
						<option value="ca">Canada</option>
						<option value="germany">Germany</option>
						<option value="aus">Australlia</option>
						<option value="uk">United Kingdom</option>
						<option value="spain">Spain</option>
						<option value="italy">Italy</option>
						<option value="france">France</option>
						<option value="malaysia">Malaysia</option>
					</select>
				</td>
			</tr>



			<tr class="adminlays">
				<td>
					<label >University</label>
				</td>
				<td>
					<input id="brandField" type="text" name="m_university" class="form-control">
				</td>
			</tr>

			<tr class="adminlay ">
				<td>
					<label>University Website</label>
				</td>
				<td>
					<input type="text" name="m_uniweb" class="form-control">
				</td>
			</tr>

			<tr class="adminlays">
				<td>
					<label>International Students Percentage</label>
				</td>
				<td>
					<input type="text" name="m_interstudent" class="form-control">
				</td>
			</tr>

			<tr class="adminlay">
				<td>
					<label>Established In</label>
				</td>
				<td>
					<input type="text" name="m_year" class="form-control">
				</td>
			</tr>





			<tr class="adminlays">
				<td>
					<label>No.of Campuses</label>
				</td>
				<td class="form-control">
					
					<input type="radio" name="m_campsize" value="1" id="1"><label for="1"> 1 </label>
					<input type="radio" name="m_campsize" value="2" id="2"><label for="2"> 2 </label>
					<input type="radio" name="m_campsize" value="3" id="3"><label for="3"> 3 </label>
					
				</td>
			</tr>
			<<tr class="adminlay">
				<td>
					<label>Campus size</label>
				</td>
				<td>
					<input type="text" name="m_campussize" class="form-control">
				</td>
			</tr>
			<tr class="adminlays">
				<td>
					<label>Male Female Ratio</label>
				</td>
				<td>
					<input type="text" name="m_malefemaleratio" class="form-control">
				</td>
			</tr>
			<tr class="adminlay">
				<td>
					<label>Endowments Value</label>
				</td>
				<td>
					<input type="number" name="m_endvalue" class="form-control">
				</td>
			</tr>

			<tr class="adminlays">
				<td>
					<label>Students Belonging To</label>
				</td>
				<td>
					<input type="text" name="m_foreignstudent" class="form-control">
				</td>
			</tr>
			<tr class="adminlay">
				<td>
					<label>Rank</label>
				</td>
				<td>
					<input type="number" name="m_rank" class="form-control">
				</td>
			</tr>

			<tr class="adminlays">
				<td>
					<label>Application Fees</label>
				</td>
				<td>
					<input type="text" name="m_applicationfee" class="form-control">
				</td>
			</tr>

			<tr class="adminlay">
				<td>
					<label>Minimum Grade Percentage</label>
				</td>
				<td>
					<input type="text" name="m_minimumGrade" class="form-control">
				</td>
			</tr>
			<tr class="adminlays">
				<td>
					<label>Address</label>
				</td>
				<td>
					<input type="text" name="m_address" class="form-control">
				</td>
			</tr>

			<tr class="adminlay">
				<td>
					<label>Phone</label>
				</td>
				<td>
					<input type="text" name="m_phone" class="form-control">
				</td>
			</tr>
			<tr class="adminlays">
				<td>
					<label>Email</label>
				</td>
				<td>
					<input type="text" name="m_uniemail" class="form-control">
				</td>
			</tr>
			<tr class="adminlay">
				<td>
					<label>City</label>
				</td>
				<td>
					<input type="text" name="m_city" class="form-control">
				</td>
			</tr>
			<tr class="adminlays">
				<td>
					<label>Yearly Hostel & Meal Cost</label>
				</td>
				<td>
					<input type="number" name="m_hostelmeal" class="form-control">
				</td>
			</tr>

			<tr class="adminlay">
				<td>
					<label>Average Tuition Fees</label>
				</td>
				<td>
					<input type="number" name="m_avgtution" class="form-control">
				</td>
			</tr>


			<tr class="adminlays">
				<td>
					<label>Description</label>
				</td>
				<td>
					<textarea name="m_description" class="form-control"></textarea>
				</td>
			</tr>

			<tr class="adminlay">
				<td>
					<label>Is everything okay ?</label>
				</td>
				<td>
					<input type="hidden" name="pass" value="asdfghjkl"></input>
					<button type="submit" name="modify_item" class="btn btn-warning">Modify Univeristy</button>
				</td>
			</tr>

		</table>
	</form>
</div>

<div class="main" style="border: 3px solid black;">
	<h1 style="text-align: center; " class="check" id="removeuni"> Remove University</h1>
	<form method="post"  enctype="multipart/form-data">
		<table class="table table-bordered">
			<tr class="warning">
				<td>
					<label>University ID</label>
				</td>
				<td>
					<input type="number" name="a_id" class="form-control">
					<input class="hidden" type="button" name="idBtn" value="Get Details">
				</td>
			</tr>

			<tr class="warning">
				<td>
					<label>Is everything okay ?</label>
				</td>
				<td>
					
				
					
					<button type="submit" name="delete_item" class="btn btn-danger">Delete University</button>
				</td>
			</tr>

		</table>
	</form>
</div>


</div>





