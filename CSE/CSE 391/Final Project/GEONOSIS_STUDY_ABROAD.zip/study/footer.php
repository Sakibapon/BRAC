</div>
<div class="container-fluid"></div>

<div class="sectionfooter "></div>

	<div class="footer sfooter ">
			<div class="col-lg-2 col-md-2 col-sm-2"></div> 
			<div class="col-lg-2  col-sm-2 col-xs-6">
				<h3 class="check">Countries</h3>
				<ul class="products-footer check">
				<li><a href="usa.php">USA</a></li>
               	<li><a href="canada.php">Canada</a></li>
                <li><a href="germany.php">Germany</a></li>
                <li><a href="aus.php">Australia</a></li>
                <li><a href="uk.php">UK</a></li>
                <li><a href="spain.php">Spain</a></li>
                <li><a href="italy.php">Italy</a></li>
                <li><a href="france.php">France</a></li>
                <li><a href="malaysia.php">Malaysia</a></li>
				</ul>
			</div>
			 <div class="col-lg-3 col-sm-3 col-xs-6">
				<h3 class="check">Our Services</h3>
				<ul class="customer check">
					<li><a href="javascript:void(Tawk_API.toggle())">Book A Consultation</a></li>
					<li><a href="mailto:sakibapon7@gmail.com">Email Us</a></li>
					<li><a href="javascript:void(Tawk_API.toggle())">Report A Problem</a></li>
					<!-- 
					<li>
							 
							<span style="color: #0000FF; text-decoration: underline; line-height: 0px !important; cursor: pointer;" id="phplive_btn_1620818977"></span>
							<script data-cfasync="false" type="text/javascript">

							(function() {
							var phplive_e_1620818977 = document.createElement("script") ;
							phplive_e_1620818977.type = "text/javascript" ;
							phplive_e_1620818977.async = true ;
							phplive_e_1620818977.src = "https://t2.phplivesupport.com/sakibapon/js/phplive_v2.js.php?v=0%7C1620818977%7C2%7C&" ;
							document.getElementById("phplive_btn_1620818977").appendChild( phplive_e_1620818977 ) ;
							if ( [].filter ) { document.getElementById("phplive_btn_1620818977").addEventListener( "click", function(){ phplive_launch_chat_0() } ) ; } else { document.getElementById("phplive_btn_1620818977").attachEvent( "onclick", function(){ phplive_launch_chat_0() } ) ; }
							})() ;

							</script>
							
					</li>
					 -->
				</ul> 
				<h3 class="check">Payment Method</h3>
				<ul class="cards">
					<li><i class="fab fa-cc-visa fa-3x"></i></li>
					<li><i class="fab fa-cc-mastercard fa-3x"></i></li>
					<li><i class="fab fa-cc-amex fa-3x"></i></li>
					<li><i class="fab fa-cc-paypal fa-3x"></i></li>
					<li><i class="fas fa-money-bill-alt fa-3x"></i></li>
					<li><img src="img/bkash.png"></li>
				</ul> 
			 </div>
			<div class="col-lg-3  col-sm-3 col-xs-12">
				<h3 class="check">Contact Us</h3>
				<ul class="contact ">
					<li><p>Phone: +880-1951445484</p></li>
					<li><p>E-mail: <a href="mailto:sakibapon7@gmail.com">sakibapon7@gmail.com</a></p></li>
					<li><p>Location : Niketon, <br>Gulshan 1, Dhaka, Bangladesh.</p></li>
				</ul>
				<h3 class="check">Find us on</h3>
				<ul class="social">
					<li><a href="https://www.facebook.com/sakibapon101/" target="_blank"><i class="fab fa-facebook-square fa-2x"></i></a></li>
					<li><a href="https://www.instagram.com/Sakib_apon" target="_blank"><i class="fab fa-instagram fa-2x"></i></a></li>
					
					<li><a href="https://twitter.com/" target="_blank"><i class="fab fa-twitter fa-2x"></i></a></li>
					<li><a href="https://www.youtube.com/channel/" target="_blank"><i class="fab fa-youtube fa-2x"></i></a></li>
					<li><a href="https://github.com/SakibApon" target="_blank"><i class="fab fa-github fa-2x"></i></a></li>
					<li><a href="https://www.linkedin.com/in/SakibApon/" target="_blank"><i class="fab fa-linkedin fa-2x"></i></a></li>
					<li><a href="https://plus.google.com/" target="_blank"><i class="fab fa-google-plus fa-2x"></i></a></li>

				</ul>
			</div>
			<div class="col-lg-12 col-sm-12 col-xs-12 copyright check"><p>&copy; <?php echo date('Y'); ?> Geonosis</p></div>
</div>




<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/606cb8f8067c2605c0bfd6c8/1f2kb5dve';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->


</div>
</html>
