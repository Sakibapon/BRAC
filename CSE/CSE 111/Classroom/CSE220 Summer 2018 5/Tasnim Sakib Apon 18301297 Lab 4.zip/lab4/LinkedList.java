public class LinkedList{
  public Node head;
  
  
  /* First Constructor:
   * Creates a linked list using the values from the given array. head will refer
   * to the Node that contains the element from a[0]
   */ 
  public LinkedList(Object [] a){
    head =new Node(a[0],null);
    Node tail=head;
    for(int i=1;i<a.length;i++){
      Node x=new Node(a[i],null);
      tail.next=x;
      tail=tail.next;
      
  }
  }
  
  /* Second Constructor:
   * Sets the value of head. head will refer
   * to the given LinkedList
   */
  public LinkedList(Node h){
   head=h;
  }
  
  /* Counts the number of Nodes in the list */
  public int countNode(){
    Node temp=head;
    int count=0;
    while(temp!=null){
      count++;
        temp=temp.next;
      
  }
    return count;
  }
  /* prints the elements in the list */
  public void printList(){
    Node temp=head;
    int count=0;
    while(temp.next!=null){
      System.out.print(temp.element+",");
        temp=temp.next;
      
  }
    System.out.print(temp.element);
    System.out.println();
   
  }
     
  
  
  // returns the reference of the Node at the given index. For invalid index return null.
  public Node nodeAt(int idx){
    Node temp=head;
    int count=0;
    while(temp!=null){
      
      if(count==idx){
      return temp;
      }
      count++;
      temp=temp.next;
  }
    return null;
  }
  
  
  
// returns the element of the Node at the given index. For invalid idx return null.
  public Object get(int idx){
   Node temp=head;
    int count=0;
    while(temp!=null){
      
      if(count==idx){
      return temp.element ;
      }
      else{
      count++;
      }
      temp=temp.next;
  }
    return null;
  }
  
  
  
  /* updates the element of the Node at the given index. 
   * Returns the old element that was replaced. For invalid index return null.
   * parameter: index, new element
   */
  public Object set(int idx, Object elem){
   Node temp=head;
    int count=0;
    while(temp!=null){
      Object jam=temp.element;
      if(count==idx){
        
        temp.element=elem;
      return jam ;
      }
      else{
      count++;
      }
      temp=temp.next;
  }
    return null;
  }
  
  
  /* returns the index of the Node containing the given element.
   if the element does not exist in the List, return -1.
   */
  public int indexOf(Object elem){
    Node temp=head;
    int count=0;
    while(temp!=null){
      
      if(temp.element==elem){
        
        return count ;
      }
      else{
      count++;
      }
      temp=temp.next;
  }
    return -1;
  }
    
 
  // returns true if the element exists in the List, return false otherwise.
  public boolean contains(Object elem){
   Node temp=head;
   boolean b=false; 
   int count=0;
    while(temp!=null){
      
      if(temp.element==elem){
        b=true;
      return b ;
      }
      
      temp=temp.next;
  }
    return b;
  }
  
  
  // Makes a duplicate copy of the given List. Returns the reference of the duplicate list.
  public Node copyList(){
   Node newHead=new Node(head.element,null);
   Node newTail=newHead;
   Node temp;
   for(temp=head.next;temp!=null;temp=temp.next){
     Node i=new Node(temp.element,null);
     newTail.next=i;
     newTail=i;
   }
   return newHead;
  }
  
  
  // Makes a reversed copy of the given List. Returns the head reference of the reversed list.
  public Node reverseList(){
    Node reverseHead=new Node(head.element,null);
    for(Node temp=head.next;temp!=null;temp=temp.next){
      Node i=new Node(temp.element,null);
      i.next=reverseHead;
      reverseHead=i;
    }
    return reverseHead;
  }
  
  /* inserts Node containing the given element at the given index
   * Check validity of index.
   */
  public void insert(Object elem, int idx){
    Node k=new Node(elem,null);
    if(idx<0||idx>countNode()){
      System.out.println("invalid index");
  }
    else if(idx==0){
      k.next=head;
      head=k;
    }
    else{
      Node p=nodeAt(idx-1);
      k.next=p.next;
      p.next=k;
    }
    }
  /* removes Node at the given index. returns element of the removed node.
   * Check validity of index. return null if index is invalid.
   */
  public Object remove(int index){
  int size=countNode();
        if(index<0||index>(size-1)){
            System.out.println("Invalid Index");
            return null;
        }
        else{
          if(index==0){
                Node removedNode=head;
                Object removedElement=head.element;
                head=head.next;
                removedNode.element=null;
                removedNode.next=null;
                return removedElement;
            }
           else{
             Node p=nodeAt(index-1);
             Node removedNode=p.next;
             Object removedElement=p.next.element;
             p.next=p.next.next;
             removedNode.element=null;
             removedNode.next=null;
             return removedElement;
            }
        }
    
  }
  
  // Rotates the list to the left by 1 position.
  public void rotateLeft(){
      Node temp=head;
        head=head.next;
        temp.next=null;
        Node n;
        for(n=head;n.next!=null;n=n.next){
        }
        n.next=temp;
  }
  
  // Rotates the list to the right by 1 position.
  public void rotateRight(){
    Node n=head;
        for(n=head;n.next!=null;n=n.next){
        }
        Node temp=n.next;
        n.next=null;
        temp.next=head;
        head=temp;
    }
  }