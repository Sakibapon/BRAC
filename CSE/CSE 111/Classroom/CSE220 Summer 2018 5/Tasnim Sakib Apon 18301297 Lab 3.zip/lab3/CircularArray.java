public class CircularArray{
  
  private int start;
  private int size;
  private Object [] cir;
  
  /*
   * if Object [] lin = {10, 20, 30, 40, null}
   * then, CircularArray(lin, 2, 4) will generate
   * Object [] cir = {40, null, 10, 20, 30}
   */
  public CircularArray(Object [] lin, int st, int sz){
    start = st;
        size = sz;
        cir = new Object [lin.length];
        int j = start;
        for(int i = 0 ; i<=size-1 ; i++){
            cir[j] = lin[i];
            j = (j+1)%cir.length;
        }
        
    }
  
  
  //Prints from index --> 0 to cir.length-1
  public void printFullLinear(){
        for(int i = 0 ; i<=cir.length-1 ; i++){
            System.out.print(cir[i]+" "); 
        }
        //System.out.println("hello"+cir[cir.length-1]);
        System.out.println();
  }
  
  // Starts Printing from index start. Prints a total of size elements
  public void printForward(){
    int j = start;
    for(int i = 0; i <=size-1; i++){
      if(i == size-1){
        System.out.print(cir[j]+".");
  }
      else{
        System.out.print(cir[j]+",");
      }
      j=(j+1)%cir.length;
    }
    System.out.println();
  }
  
  public void printBackward(){
  int j=(start+size-1)%cir.length;
  for(int i=0;i<=size-1;i++){
    if(i==size-1){
    System.out.print(cir[j]+".");
    }
     else{
        System.out.print(cir[j]+",");
      }
    j--;
    if(j<0){
      j=cir.length+j;
  }
  }
  System.out.println();
  }
  
  // With no null cells
  public void linearize(){
    Object[] trian=new Object[size];
    int j=start;
    for(int i=0;i<=trian.length-1;i++){
      trian[i]=cir[j];
      j=(j+1)%cir.length;
  }
    cir=trian;
    
  }
  // Do not change the Start index
  public void resizeStartUnchanged(int newcapacity){
     Object[] trian=new Object[newcapacity];
     int j=start,k=start;
     for(int i=0;i<=size-1;i++){
       trian[j]=cir[k];
       j=(j+1)%trian.length;
       k=(k+1)%cir.length;
  }
  cir=trian;
  }
  // Start index becomes zero
  public void resizeByLinearize(int newcapacity){
   Object[] trian=new Object[newcapacity];
  int j=start;
  for(int i=0;i<=size-1;i++){
    trian[i]=cir[j];
    j=(j+1)%cir.length;
  }
  cir=trian;
  }
  /* pos --> position relative to start. Valid range of pos--> 0 to size.
   * Increase array length by 3 if size==cir.length
   * use resizeStartUnchanged() for resizing.
   */
  public void insertByRightShift(Object elem, int pos){
   if(size==cir.length){
     resizeStartUnchanged(cir.length+3);   
            }
      if(pos>=0||pos<=size){
        int index=(start+pos)%cir.length;
        int numOfShift=size-pos;
        int j=(start+size-1)%cir.length;
        int k=(start+size)%cir.length;
        for(int i=0;i<=numOfShift-1;i++){
          cir[k]=cir[j];
          j--;
          if(j<0){
            j=j+cir.length;
          }
          k--;
          if(k<0){
            k=k+cir.length;
          }
        }
        cir[index]=elem;
        size++;
      }
    }
  
          
  
  
  public void insertByLeftShift(Object elem, int pos){
     if(size==cir.length){
     resizeStartUnchanged(cir.length+3);
     }
      if(pos>=0||pos<=size){
       // int index=(start+pos)%cir.length;
  
      int index=(start+pos)%cir.length;
        int numOfShift=pos+1;
        int i=(start-1)%cir.length;
        int j=(start)%cir.length;
        for(int k=0;k<=numOfShift-1;k++){
          cir[i]=cir[j];
          i++;
         // if(i<0){
           // i=i+cir.length;
          //}
          j++;
          //if(j<0){
            //j=j+cir.length;
          }
        
        cir[index]=elem;
         size++;
         start--;
  }
}
  /* parameter--> pos. pos --> position relative to start.
   * Valid range of pos--> 0 to size-1
   */
  public void removeByLeftShift(int pos){
    if(size!=0){
      if(pos>=0&&pos<size){
         int index=(start+pos)%cir.length;
        int numOfShift=size-pos-1;
        int i=index;
        int j=(i+1)%cir.length;
        for(int k=0;k<=numOfShift-1;k++){
          cir[i]=cir[j];
          //i=j;
          //j=(j+1)%cir.length;
        }
        System.out.println("jigyftr7"+ j);
       cir[j]=null;
       size--;
  }
    }
  }
  
  /* parameter--> pos. pos --> position relative to start.
   * Valid range of pos--> 0 to size-1
   */
  public void removeByRightShift(int pos){
     if(size!=0){
      if(pos>=0&&pos<size){
         int index=(start+pos)%cir.length;
        int numOfShift=size-pos;
        int i=index;
        int j=index-1;
        if(j==-1){
          j=j+cir.length;
        }
        for(int k=0;k<start;k++){
          cir[i]=cir[j];
          i=j;
          j=j-1;
          if(j==-1){
            j=cir.length+j;
          }
        }
          cir[start]=null;
          size--;
          start=(start+1)%cir.length;
  }
      }
     }
  
     
 //This method will check whether the array is palindrome or not
  public void palindromeCheck(){
   int count=0;
   int i=start%cir.length;
   int j=(start+size-1)%cir.length;
   for(int k=0;k<size/2;k++){
     if(cir[i]!=cir[j]){
       count++;
       break;
     }
     i++;
     j--;
     if(i>cir.length){
       i=0;
     }
     if(j<cir.length){
       j=cir.length+j;
     }
   
     }
    if(count==0){
       System.out.println("This array is a palindrome");
     }
     else{
       System.out.println("This array is noooooot a palindrome");
   }
  }
  
  
  //This method will sort the values by keeping the start unchanged
    public void sort(){
    for(int i=start%cir.length;i<=size-1;i++){
      for(int j=(i+1)%cir.length;j<=size-1;j++){
        if((Integer)cir[j]<(Integer)cir[i]){
          Object temp=cir[i];
          cir[i]=cir[j];
          cir[j]=temp;
  }
            
       
          if(i>cir.length){
          i=i%cir.length;
        }
      }
    }
  }
  //This method will check the given array across the base array and if they are equivalent interms of values return true, or else return false
  public boolean equivalent(CircularArray k){
    boolean b = true;
        for(int i = 0; i < size; i++){
            if(cir[(i+start)%cir.length] != k.cir[(i+k.start)%k.cir.length]){
                b = false;
            }
        }
        return b; 
    }
}