public class ArrayQueue implements Queue{
    int size;
    int front;
    int rear;
    Object [] data;
    
    public ArrayQueue(){
        size=0;
        front = -1;
        rear = -1;
        data = new Object[5];
    }
    
//TO DO
    // The number of items in the queue
    public int size(){
      return size;//remove
    }
    
// Returns true if the queue is empty
    public boolean isEmpty(){
      if(size==0){
        return true;
      }
      else{
        return false;
      }
    }
    
// Adds the new item on the back of the queue, throwing the
// QueueOverflowException if the queue is at maximum capacity. It
// does not throw an exception for an "unbounded" queue, which 
// dynamically adjusts capacity as needed.
    public void enqueue(Object o) throws QueueOverflowException{
      if(size==0){
        data[0] = o;
        front=0;
        rear=0;
        size=1;
      }
      else if(size==data.length){
        throw new QueueOverflowException();
      }
      else{
        rear=(rear+1)%data.length;
        data[rear]=o;
        size++;
      }
      
    }
// Removes the item in the front of the queue, throwing the 
// QueueUnderflowException if the queue is empty.
    public Object dequeue() throws QueueUnderflowException{
      Object r;
      if(size==0){
        throw new QueueUnderflowException();
      }
      else if(size==1){
        r=data[front];
        front=-1;rear=-1;
        size=0;
      }
      else{
        r=data[front];
        //data[front]=0;
        front=(front+1)%data.length;
        size--;
      }
      return r;
    }

// Peeks at the item in the front of the queue, throwing
// QueueUnderflowException if the queue is empty.
    public Object peek() throws QueueUnderflowException{
      if(size==0){
        throw new QueueUnderflowException();
      }
      else{
        return data[front];
      }
    }

// Returns a textual representation of items in the queue, in the
// format "[ x y z ]", where x and z are items in the front and
// back of the queue respectively.
    public String toString(){
      int st=front;
      for(int c=0;c<size;c++){
        if(c==0){
          System.out.print("["+data[st]);
          st=(st+1)%data.length;
        }
        else if(c==size-1){
          System.out.print(","+data[st]+".]");
          st=(st+1)%data.length;
        }
        else{
          System.out.print(","+data[st]);
          st=(st+1)%data.length;
        }
      }
      System.out.println();
      return "";
    }

// Returns an array with items in the queue, with the item in the
// front of the queue in the first slot, and back in the last slot.
    public Object[] toArray(){
      Object[] a = new Object[size];
      int f=front;
      for(int c=0;c<a.length;c++){
        a[c] = data[f];
        f = (f+1)%data.length;
      }
      return a;
    }

// Searches for the given item in the queue, returning the
// offset from the front of the queue if item is found, or -1
// otherwise.
    public int search(Object o){
      int st=front;
      for(int c=0;c<size;c++){
        if(data[st]==o){
          return c;
        }
        st=(st+1)%data.length;
      }
      return -1;
    }
    
}